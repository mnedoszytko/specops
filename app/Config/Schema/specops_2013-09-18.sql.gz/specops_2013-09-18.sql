# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: localhost (MySQL 5.5.29)
# Database: specops
# Generation Time: 2013-09-18 19:01:14 +0200
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table events
# ------------------------------------------------------------

DROP TABLE IF EXISTS `events`;

CREATE TABLE `events` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `schedule_id` int(11) DEFAULT NULL,
  `reqevent_id` int(11) NOT NULL,
  `start` date DEFAULT NULL,
  `end` date DEFAULT NULL,
  `completed` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;

INSERT INTO `events` (`id`, `schedule_id`, `reqevent_id`, `start`, `end`, `completed`)
VALUES
	(2,1,1,'2010-03-29','2010-04-02',1),
	(3,1,6,'2013-02-14','2013-02-15',1),
	(4,1,6,'2013-02-21','2013-02-22',1),
	(5,1,4,'2013-09-17','2013-09-18',1),
	(6,1,2,'2011-11-21','2011-11-25',1),
	(7,1,3,'2013-06-17','2013-06-21',1),
	(8,1,5,'2013-09-23','2013-10-11',0),
	(9,1,19,'2012-09-03','2012-09-28',1),
	(10,1,10,'2009-02-02','2009-03-13',1),
	(11,1,11,'2009-08-31','2009-09-25',0),
	(12,1,14,'2010-03-01','2010-03-27',1),
	(13,1,13,'2010-08-30','2010-10-08',1),
	(14,1,18,'2012-01-09','2012-01-20',1),
	(15,1,9,'2012-06-08','2012-08-31',0),
	(16,1,11,'2013-08-01','2013-08-29',1);

/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table freedays
# ------------------------------------------------------------

DROP TABLE IF EXISTS `freedays`;

CREATE TABLE `freedays` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `freedays` WRITE;
/*!40000 ALTER TABLE `freedays` DISABLE KEYS */;

INSERT INTO `freedays` (`id`, `name`, `date`)
VALUES
	(1,'boże ciało 2010','2010-06-03'),
	(2,'boże ciało 2011','2011-06-23'),
	(3,'boże ciało 2012','2012-06-07'),
	(4,'boże ciało 2013','2013-05-30'),
	(5,'boże ciało 2008','2008-05-22'),
	(6,'boże ciało 2009','2009-06-11'),
	(7,'lany poniedziałek 2008','2008-03-24'),
	(8,'lany pon 2009','2009-04-13'),
	(9,'lany pon 2010','2010-04-05'),
	(10,'lany pon 2011','2011-04-25'),
	(11,'lany pon 2012','2012-04-09'),
	(12,'lany pon 2013','2013-04-01');

/*!40000 ALTER TABLE `freedays` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table reqevents
# ------------------------------------------------------------

DROP TABLE IF EXISTS `reqevents`;

CREATE TABLE `reqevents` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `spec_id` int(11) DEFAULT NULL,
  `name` varchar(256) NOT NULL,
  `type` varchar(1) NOT NULL,
  `days` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `reqevents` WRITE;
/*!40000 ALTER TABLE `reqevents` DISABLE KEYS */;

INSERT INTO `reqevents` (`id`, `spec_id`, `name`, `type`, `days`)
VALUES
	(1,1,'Kurs wprowadzajÄ…cy','k',5),
	(2,1,'Diagnostyka obrazowa','k',5),
	(3,1,'Onkologia','k',5),
	(4,1,'Transfuzjologia','k',2),
	(5,1,'Kurs podsumowujÄ…cy','k',15),
	(6,1,'Zdrowie publiczne','k',4),
	(7,1,'Choroby wewnÄ™trzne','s',1150),
	(8,1,'Intensywna terapia','s',60),
	(9,1,'Kardiologia','s',60),
	(10,1,'Pulmonologia','s',30),
	(11,1,'Endokrynologia','s',20),
	(12,1,'Diabetologia','s',10),
	(13,1,'Gastroenterologia','s',30),
	(14,1,'Nefrologia','s',20),
	(15,1,'Reumatologia','s',20),
	(16,1,'Choroby zakaÅºne','s',20),
	(17,1,'Neurologia','s',10),
	(18,1,'Psychiatria','s',10),
	(19,1,'Hematologia','s',20);

/*!40000 ALTER TABLE `reqevents` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table schedules
# ------------------------------------------------------------

DROP TABLE IF EXISTS `schedules`;

CREATE TABLE `schedules` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `spec_id` int(11) DEFAULT NULL,
  `name` varchar(128) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `start` date NOT NULL,
  `end` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;

INSERT INTO `schedules` (`id`, `spec_id`, `name`, `created`, `modified`, `start`, `end`)
VALUES
	(1,1,'Interna-Nedo','2013-09-10 10:53:51','2013-09-10 10:53:51','2008-12-01','2013-11-30');

/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table specs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `specs`;

CREATE TABLE `specs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `specs` WRITE;
/*!40000 ALTER TABLE `specs` DISABLE KEYS */;

INSERT INTO `specs` (`id`, `name`)
VALUES
	(1,'Choroby wewnÄ™trzne');

/*!40000 ALTER TABLE `specs` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
